<?php
define("DBHOST","localhost");
define("DBPORT",3306);
define("DBUSER","root");
define("DBPASS","");
define("DBNAME","safedrive");



?>