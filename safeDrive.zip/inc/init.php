<?php
include_once('config.php');
include_once('database.php');
include_once ('dept_name.php');
?>
